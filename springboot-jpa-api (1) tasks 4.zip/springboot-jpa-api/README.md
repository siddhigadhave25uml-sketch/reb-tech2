# Spring Boot REST API & Hibernate / JPA Persistence

A Student Management REST API demonstrating Spring Boot, Spring Data JPA, Hibernate, validation, entity relationships, and CRUD endpoints.

## Requirements
- Java 21
- Maven (or use your IDE's Maven support)
- Optional: MySQL, if you switch from the default H2 database

## Run in VS Code
1. Extract the ZIP and open the `springboot-jpa-api` folder in VS Code.
2. Install the Java Extension Pack if prompted.
3. Make sure Java 21 is installed.
4. In the terminal, run:
   - Windows: `mvnw.cmd spring-boot:run` (if Maven Wrapper is present) or `mvn spring-boot:run`
   - macOS/Linux: `./mvnw spring-boot:run` or `mvn spring-boot:run`
5. API base URL: `http://localhost:8080`

This starter ZIP does not include Maven Wrapper files. Install Maven or run through the IDE's Maven panel.

Default database is H2 in-memory so the app can run without MySQL. Data resets when the app restarts. H2 console: `http://localhost:8080/h2-console`; JDBC URL: `jdbc:h2:mem:student_api`, user `sa`, password blank.

## API endpoints

### Departments
- `GET /api/departments`
- `GET /api/departments/{id}`
- `POST /api/departments`
- `PUT /api/departments/{id}`
- `DELETE /api/departments/{id}`

Create a department:
```json
{ "name": "Computer Science" }
```

### Students
- `GET /api/students`
- `GET /api/students/{id}`
- `GET /api/students?search=shruti`
- `GET /api/students/by-department/{departmentId}`
- `POST /api/students?departmentId=1`
- `PUT /api/students/{id}?departmentId=1`
- `DELETE /api/students/{id}`

Create a student (first create a department and use its ID):
```json
{ "name": "Shruti Gadhave", "email": "shruti@example.com" }
```

## Quick test sequence
1. POST `/api/departments` with `{ "name": "Computer Science" }`
2. POST `/api/students?departmentId=1` with `{ "name": "Test Student", "email": "student@example.com" }`
3. GET `/api/students`
4. PUT `/api/students/1?departmentId=1` with `{ "name": "Updated Student", "email": "updated@example.com" }`
5. DELETE `/api/students/1`

Use Postman or curl. POST requests should use `Content-Type: application/json`.

## Implementation checklist
- [x] JPA entities with `@Entity` and `@Table`
- [x] `@OneToMany` and `@ManyToOne` relationship
- [x] Spring Data `JpaRepository`
- [x] Custom JPQL `@Query`
- [x] GET, POST, PUT, DELETE endpoints
- [x] Jakarta validation (`@NotNull`, `@Size`, `@Email`, `@NotBlank`)
- [x] Centralized API error responses
- [ ] Run locally and test all endpoints
- [ ] Push to your GitHub repository and include screenshots as proof

## Before submission
Run the project and test the endpoints yourself. Do not claim successful testing until it runs locally. Do not commit passwords or other secrets.
