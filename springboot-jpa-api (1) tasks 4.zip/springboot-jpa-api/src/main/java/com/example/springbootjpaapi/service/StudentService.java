package com.example.springbootjpaapi.service;

import com.example.springbootjpaapi.entity.Department;
import com.example.springbootjpaapi.entity.Student;
import com.example.springbootjpaapi.repository.DepartmentRepository;
import com.example.springbootjpaapi.repository.StudentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class StudentService {
    private final StudentRepository students;
    private final DepartmentRepository departments;
    public StudentService(StudentRepository students, DepartmentRepository departments) {
        this.students = students; this.departments = departments;
    }
    public List<Student> findAll() { return students.findAll(); }
    public Student findById(Long id) {
        return students.findById(id).orElseThrow(() -> new ResourceNotFoundException("Student", id));
    }
    public List<Student> search(String keyword) { return students.searchByName(keyword == null ? "" : keyword); }
    public List<Student> byDepartment(Long id) {
        if (!departments.existsById(id)) throw new ResourceNotFoundException("Department", id);
        return students.findByDepartmentId(id);
    }
    @Transactional
    public Student create(Student input, Long departmentId) {
        if (students.existsByEmailIgnoreCase(input.getEmail()))
            throw new ConflictException("A student with this email already exists");
        Department department = departments.findById(departmentId)
            .orElseThrow(() -> new ResourceNotFoundException("Department", departmentId));
        input.setDepartment(department);
        return students.save(input);
    }
    @Transactional
    public Student update(Long id, Student input, Long departmentId) {
        Student current = findById(id);
        students.findByEmailIgnoreCase(input.getEmail()).ifPresent(existing -> {
            if (!existing.getId().equals(id)) throw new ConflictException("A student with this email already exists");
        });
        Department department = departments.findById(departmentId)
            .orElseThrow(() -> new ResourceNotFoundException("Department", departmentId));
        current.setName(input.getName());
        current.setEmail(input.getEmail());
        current.setDepartment(department);
        return students.save(current);
    }
    @Transactional
    public void delete(Long id) { students.delete(findById(id)); }
}
