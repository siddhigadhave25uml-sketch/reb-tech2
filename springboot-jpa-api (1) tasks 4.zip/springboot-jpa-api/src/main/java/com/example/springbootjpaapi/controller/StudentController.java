package com.example.springbootjpaapi.controller;

import com.example.springbootjpaapi.entity.Student;
import com.example.springbootjpaapi.service.StudentService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/students")
@Validated
public class StudentController {
    private final StudentService service;
    public StudentController(StudentService service) { this.service = service; }

    @GetMapping public List<Student> all(@RequestParam(required = false) String search) {
        return search == null ? service.findAll() : service.search(search);
    }
    @GetMapping("/{id}") public Student one(@PathVariable Long id) { return service.findById(id); }
    @GetMapping("/by-department/{departmentId}")
    public List<Student> byDepartment(@PathVariable Long departmentId) { return service.byDepartment(departmentId); }

    @PostMapping @ResponseStatus(HttpStatus.CREATED)
    public Student create(@Valid @RequestBody Student student,
                          @RequestParam @NotNull(message = "departmentId is required") Long departmentId) {
        return service.create(student, departmentId);
    }
    @PutMapping("/{id}")
    public Student update(@PathVariable Long id, @Valid @RequestBody Student student,
                          @RequestParam @NotNull(message = "departmentId is required") Long departmentId) {
        return service.update(id, student, departmentId);
    }
    @DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) { service.delete(id); }
}
