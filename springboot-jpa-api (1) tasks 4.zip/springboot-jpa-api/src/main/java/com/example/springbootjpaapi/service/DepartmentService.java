package com.example.springbootjpaapi.service;

import com.example.springbootjpaapi.entity.Department;
import com.example.springbootjpaapi.repository.DepartmentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class DepartmentService {
    private final DepartmentRepository repository;
    public DepartmentService(DepartmentRepository repository) { this.repository = repository; }

    public List<Department> findAll() { return repository.findAll(); }
    public Department findById(Long id) {
        return repository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Department", id));
    }
    @Transactional
    public Department create(Department department) {
        if (repository.existsByNameIgnoreCase(department.getName()))
            throw new ConflictException("A department with this name already exists");
        return repository.save(department);
    }
    @Transactional
    public Department update(Long id, Department input) {
        Department current = findById(id);
        if (!current.getName().equalsIgnoreCase(input.getName()) && repository.existsByNameIgnoreCase(input.getName()))
            throw new ConflictException("A department with this name already exists");
        current.setName(input.getName());
        return repository.save(current);
    }
    @Transactional
    public void delete(Long id) {
        Department department = findById(id);
        if (!department.getStudents().isEmpty())
            throw new ConflictException("Delete or reassign this department's students first");
        repository.delete(department);
    }
}
