package com.example.springbootjpaapi.repository;

import com.example.springbootjpaapi.entity.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;
import java.util.Optional;

public interface StudentRepository extends JpaRepository<Student, Long> {
    Optional<Student> findByEmailIgnoreCase(String email);
    boolean existsByEmailIgnoreCase(String email);

    @Query("select s from Student s where lower(s.name) like lower(concat('%', :keyword, '%'))")
    List<Student> searchByName(@Param("keyword") String keyword);

    List<Student> findByDepartmentId(Long departmentId);
}
